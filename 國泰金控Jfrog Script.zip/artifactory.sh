#!/bin/bash

# Variables
SETUP_DIR="/tmp/setup"
DEB_DIR="$SETUP_DIR/deb"
ARTIFACTORY_VERSION="7.98.8"
ARTIFACTORY_PACKAGE="jfrog-artifactory-pro-${ARTIFACTORY_VERSION}.deb"
SYSCTL_CONF="/etc/sysctl.conf"
HOSTS_FILE="/etc/hosts"
SYSTEM_YAML="/opt/jfrog/artifactory/var/etc/system.yaml"
DB_TYPE="postgresql"
DB_DRIVER="org.postgresql.Driver"
DB_HOST="34.80.22.57"
DB_PORT="5432"
DB_NAME="artifactorydb"
DB_USERNAME="artifactory"
DB_PASSWORD="password"

# Disable IPv6
echo "Disabling IPv6..."
echo "net.ipv6.conf.all.disable_ipv6 = 1" >> "$SYSCTL_CONF"
echo "net.ipv6.conf.default.disable_ipv6 = 1" >> "$SYSCTL_CONF"
sysctl -p

# Comment out 127.0.1.1 in /etc/hosts
sed -i '/127.0.1.1/s/^/#/' "$HOSTS_FILE"

# Install net-tools dependency from local .deb package
echo "Checking if $DEB_DIR exists..."
if [ ! -d "$DEB_DIR" ]; then
    echo "$DEB_DIR does not exist. Creating the directory..."
    mkdir -p "$DEB_DIR"
fi

echo "Installing net-tools dependency from $DEB_DIR..."
dpkg -i "$DEB_DIR/"*.deb || sudo apt-get install -f -y

# Setup directory and check Artifactory package
echo "Setting up installation directory..."
if [ -f "$SETUP_DIR/$ARTIFACTORY_PACKAGE" ]; then
    echo "Found Artifactory package in $SETUP_DIR."
else
    echo "Error: Artifactory package not found in $SETUP_DIR!"
    exit 1
fi

# Install Artifactory
echo "Installing JFrog Artifactory..."
dpkg -i "$SETUP_DIR/$ARTIFACTORY_PACKAGE" || sudo apt-get install -f -y

# Modify configuration file and Display modified settings
echo "Configuring database connection..."
sudo sed -i "s|#   type: postgresql|   type: ${DB_TYPE}|" "$SYSTEM_YAML"
sudo sed -i "s|#   driver: org.postgresql.Driver|   driver: ${DB_DRIVER}|" "$SYSTEM_YAML"
sudo sed -i "s|#   url: \"jdbc:postgresql://<your db url, for example: localhost:5432>/artifactory\"|   url: \"jdbc:${DB_TYPE}://${DB_HOST}:${DB_PORT}/${DB_NAME}\"|" "$SYSTEM_YAML"
sudo sed -i "s|#   username: artifactory|   username: ${DB_USERNAME}|" "$SYSTEM_YAML"
sudo sed -i "s|#   password: password|   password: ${DB_PASSWORD}|" "$SYSTEM_YAML"

echo "Verifying configuration..."
grep -E "type|driver|url|username|password" "$SYSTEM_YAML"

# Start Artifactory service and Check Artifactory status
echo "Starting Artifactory service..."
systemctl start artifactory

echo "Checking Artifactory service status..."
systemctl status artifactory
