#!/bin/bash

set -e  # Exit the script immediately if any command exits with a non-zero status
set -x  # Print commands and their arguments as they are executed (for debugging)

# Ensure the script is run as root
if [ "$EUID" -ne 0 ]; then
  echo "Please run this script as root."
  exit 1
fi

# Variables
SETUP_DIR="/tmp/setup"
DEB_DIR="$SETUP_DIR/deb"
XRAY_VERSION="3.104.18"  # Update Xray version as needed
INSTALL_DIR="/var/opt/jfrog/xray"  # Installation directory
TAR_FILE="$SETUP_DIR/jfrog-xray-${XRAY_VERSION}-deb.tar.gz"
JFROG_URL="http://35.229.147.81:8082"  # JFrog platform URL
JOIN_KEY="41320dfc968b76f84a1331baa6d7daeb"  # Join Key
MACHINE_IP="10.140.0.6"  # Local machine IP
POSTGRES_URL="postgres://34.80.22.57:5432/xraydb?sslmode=disable"  # PostgreSQL connection URL
DB_USERNAME="xray"  # Database username
DB_PASSWORD="password"  # Database password

# Disable IPv6
echo "Disabling IPv6..."
SYSCTL_CONF="/etc/sysctl.conf"
if ! grep -q "net.ipv6.conf.all.disable_ipv6 = 1" "$SYSCTL_CONF"; then
    echo "net.ipv6.conf.all.disable_ipv6 = 1" >> "$SYSCTL_CONF"
fi
if ! grep -q "net.ipv6.conf.default.disable_ipv6 = 1" "$SYSCTL_CONF"; then
    echo "net.ipv6.conf.default.disable_ipv6 = 1" >> "$SYSCTL_CONF"
fi
sysctl -p

# Comment out 127.0.1.1 in /etc/hosts
echo "Commenting out 127.0.1.1 in /etc/hosts if present..."
sed -i 's/^127.0.1.1/#&/' /etc/hosts

# Set file limits for root, xray users
echo "Setting file limits for root, xray, and postgres users..."
LIMITS_CONF="/etc/security/limits.conf"

add_limit() {
    USER="$1"
    if ! grep -q "^$USER hard nofile" "$LIMITS_CONF"; then
        echo "$USER hard nofile 100000" >> "$LIMITS_CONF"
    fi
    if ! grep -q "^$USER soft nofile" "$LIMITS_CONF"; then
        echo "$USER soft nofile 100000" >> "$LIMITS_CONF"
    fi
}

add_limit "root"
add_limit "xray"

# Install Dependency from local .deb package
echo "Checking if $DEB_DIR exists..."
if [ ! -d "$DEB_DIR" ]; then
    echo "$DEB_DIR does not exist. Creating the directory..."
    mkdir -p "$DEB_DIR"
fi

echo "Installing Dependency from $DEB_DIR..."
dpkg -i "$DEB_DIR/"*.deb || sudo apt-get install -f -y


# Extract the JFrog Xray .tar.gz file
echo "Extracting JFrog Xray..."
if ! tar zxf "$TAR_FILE" -C /opt; then
    echo "Failed to extract the file, please check if the tar file is complete."
    exit 1
fi

cd /opt/jfrog-xray-${XRAY_VERSION}-deb || exit

# Use expect script to automate the installation process
echo "Starting JFrog Xray setup automation using expect script..."
expect <<EOF
spawn ./install.sh
expect "Installation Directory" { send "$INSTALL_DIR\r" }
expect "JFrog URL" { send "$JFROG_URL\r" }
expect "Join Key" { send "$JOIN_KEY\r" }
expect "IP address of this machine" { send "$MACHINE_IP\r" }
expect "Are you adding an additional node" { send "n\r" }
expect "Do you want to install PostgreSQL" { send "n\r" }
expect "PostgreSQL url" { send "$POSTGRES_URL\r" }
expect "Database username" { send "$DB_USERNAME\r" }
expect "Database password" { send "$DB_PASSWORD\r" }
expect {
    "Installing/Verifying Xray" { sleep 300; exp_continue }
    eof
}
EOF

# Ensure the installation is complete before proceeding, check if install.sh is still running
echo "Checking if install.sh process is still running..."
while pgrep -f "./install.sh" > /dev/null; do
    echo "install.sh is still running, waiting for it to complete..."
    sleep 10
done

# Start JFrog Xray after installation
echo "Starting JFrog Xray service..."
systemctl start xray
systemctl enable xray

echo "Setup completed."
